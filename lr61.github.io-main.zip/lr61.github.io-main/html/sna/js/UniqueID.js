let id = 0;
module.exports = {
	get ID(){
		return id++;
	}
}