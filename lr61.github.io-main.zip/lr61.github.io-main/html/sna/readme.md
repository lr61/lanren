# 贪吃蛇大战H5版本
入口 index.html，可以直接打开，bundlejs是用browserify打包的
先用bable编译js文件夹到scripts，然后再用browserify打包scripts

## PC版操作
鼠标点击一下之后就可以控制方向，按A加速

## 移动端操作
左侧操纵杆控制方向，右侧控制加速