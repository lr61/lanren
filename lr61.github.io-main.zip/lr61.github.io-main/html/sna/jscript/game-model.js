var game = this.game || {};

(function(game){
	var playgroundM = game.motion.playground = function(coords){
		this.coords = coords;
	} 
åå

}).call(window, game);